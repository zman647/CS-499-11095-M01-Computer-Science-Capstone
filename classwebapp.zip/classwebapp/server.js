const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const csvParser = require('csv-parser');
const fastCsv = require('fast-csv');
const multer = require('multer');
const util = require('util');

const app = express();
const db = new sqlite3.Database('./database.db'); // Using a file-based SQLite database

// Promisify the SQLite functions
const getAsync = util.promisify(db.get).bind(db);
const allAsync = util.promisify(db.all).bind(db);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Set up multer for file uploads
const upload = multer({ dest: 'uploads/' });

// Create tables and insert sample data
db.serialize(() => {
    console.log("Setting up database...");
    
    // Users table
    db.run(`CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT,
        last_name TEXT,
        email TEXT UNIQUE,
        classes_taken TEXT
    )`);

    // Original Classes table
    db.run(`CREATE TABLE IF NOT EXISTS classes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        class_name TEXT
    )`);

    // Prerequisites table for original classes
    db.run(`CREATE TABLE IF NOT EXISTS prerequisites (
        class_id INTEGER,
        prerequisite_id INTEGER,
        FOREIGN KEY(class_id) REFERENCES classes(id),
        FOREIGN KEY(prerequisite_id) REFERENCES classes(id)
    )`);

    // Insert courses and populate classMap after all classes have been inserted
    const classes = [
        'CS 101 - Introduction to Programming', 'CS 201 - Data Structures', 'CS 301 - Algorithms',
        'CS 401 - Operating Systems', 'CS 501 - Machine Learning',
        'MATH 101 - Calculus I', 'MATH 201 - Calculus II', 'MATH 301 - Linear Algebra',
        'MATH 401 - Differential Equations', 'MATH 501 - Real Analysis',
        'PHYS 101 - General Physics I', 'PHYS 201 - General Physics II', 'PHYS 301 - Modern Physics',
        'PHYS 401 - Quantum Mechanics', 'PHYS 501 - Statistical Mechanics',
        'CHEM 101 - General Chemistry I', 'CHEM 201 - Organic Chemistry I', 'CHEM 301 - Organic Chemistry II',
        'CHEM 401 - Physical Chemistry', 'CHEM 501 - Inorganic Chemistry',
        'BIO 101 - General Biology I', 'BIO 201 - Genetics', 'BIO 301 - Microbiology',
        'BIO 401 - Molecular Biology', 'BIO 501 - Evolutionary Biology'
    ];

    const classMap = {};

    const stmt = db.prepare("INSERT INTO classes (class_name) VALUES (?)");
    classes.forEach(class_name => {
        stmt.run(class_name, function() {
            classMap[class_name] = this.lastID;
            console.log(`Inserted class: ${class_name}, ID: ${this.lastID}`);
            if (Object.keys(classMap).length === classes.length) {
                console.log("All classes inserted, now inserting prerequisites...");
                insertPrerequisites(classMap); // Insert prerequisites after all classes are inserted
            }
        });
    });
    stmt.finalize();

    function insertPrerequisites(classMap) {
        const prereqStmt = db.prepare("INSERT INTO prerequisites (class_id, prerequisite_id) VALUES (?, ?)");

        const prereqPairs = [
            { class: 'CS 201 - Data Structures', prereq: 'CS 101 - Introduction to Programming' },
            { class: 'CS 301 - Algorithms', prereq: 'CS 201 - Data Structures' },
            { class: 'CS 401 - Operating Systems', prereq: 'CS 301 - Algorithms' },
            { class: 'CS 501 - Machine Learning', prereq: 'CS 401 - Operating Systems' },
            { class: 'MATH 201 - Calculus II', prereq: 'MATH 101 - Calculus I' },
            { class: 'MATH 301 - Linear Algebra', prereq: 'MATH 201 - Calculus II' },
            { class: 'MATH 401 - Differential Equations', prereq: 'MATH 301 - Linear Algebra' },
            { class: 'MATH 501 - Real Analysis', prereq: 'MATH 401 - Differential Equations' },
            { class: 'PHYS 201 - General Physics II', prereq: 'PHYS 101 - General Physics I' },
            { class: 'PHYS 301 - Modern Physics', prereq: 'PHYS 201 - General Physics II' },
            { class: 'PHYS 401 - Quantum Mechanics', prereq: 'PHYS 301 - Modern Physics' },
            { class: 'PHYS 501 - Statistical Mechanics', prereq: 'PHYS 401 - Quantum Mechanics' },
            { class: 'CHEM 201 - Organic Chemistry I', prereq: 'CHEM 101 - General Chemistry I' },
            { class: 'CHEM 301 - Organic Chemistry II', prereq: 'CHEM 201 - Organic Chemistry I' },
            { class: 'CHEM 401 - Physical Chemistry', prereq: 'CHEM 301 - Organic Chemistry II' },
            { class: 'CHEM 501 - Inorganic Chemistry', prereq: 'CHEM 401 - Physical Chemistry' },
            { class: 'BIO 201 - Genetics', prereq: 'BIO 101 - General Biology I' },
            { class: 'BIO 301 - Microbiology', prereq: 'BIO 201 - Genetics' },
            { class: 'BIO 401 - Molecular Biology', prereq: 'BIO 301 - Microbiology' },
            { class: 'BIO 501 - Evolutionary Biology', prereq: 'BIO 401 - Molecular Biology' }
        ];

        prereqPairs.forEach(pair => {
            if (classMap[pair.class] && classMap[pair.prereq]) {
                prereqStmt.run(classMap[pair.class], classMap[pair.prereq]);
                console.log(`Inserted prerequisite: ${pair.class} requires ${pair.prereq}`);
            }
        });

        prereqStmt.finalize();
    }
});

// Root route: Serve the login/register page
app.get('/', (req, res) => {
    res.render('index.ejs', { message: null });
});

// Handle registration and login
app.post('/register', (req, res) => {
    const { first_name, last_name, email } = req.body;
    db.get("SELECT * FROM users WHERE email = ?", [email], (err, row) => {
        if (err) {
            console.error("Error during registration:", err);
            return res.render('index.ejs', { message: 'An error occurred. Please try again.' });
        }
        if (row) {
            console.log("Account already exists for email:", email);
            return res.render('index.ejs', { message: 'Account already exists. Please log in.' });
        }
        db.run(`INSERT INTO users (first_name, last_name, email) VALUES (?, ?, ?)`,
            [first_name, last_name, email], function(err) {
                if (err) {
                    console.error("Error during registration:", err);
                    return res.render('index.ejs', { message: 'An error occurred. Please try again.' });
                }
                console.log("User registered with ID:", this.lastID);
                res.redirect(`/dashboard?user_id=${this.lastID}`);
            });
    });
});

app.post('/login', (req, res) => {
    const { first_name, last_name, email } = req.body;
    db.get("SELECT * FROM users WHERE first_name = ? AND last_name = ? AND email = ?", [first_name, last_name, email], (err, row) => {
        if (err) {
            console.error("Error during login:", err);
            return res.render('index.ejs', { message: 'An error occurred. Please try again.' });
        }
        if (!row) {
            console.log("No account found for:", email);
            return res.render('index.ejs', { message: 'Account does not exist. Please register.' });
        }
        console.log("User logged in with ID:", row.id);
        res.redirect(`/dashboard?user_id=${row.id}`);
    });
});

// Function to get available classes
function getAvailableClasses(userId, callback) {
    db.get("SELECT classes_taken FROM users WHERE id = ?", [userId], (err, user) => {
        if (err) {
            console.error("Error fetching user:", err);
            return callback(err);
        }

        const takenClasses = user.classes_taken ? user.classes_taken.split(',') : [];

        db.all("SELECT DISTINCT class_name FROM classes", [], (err, rows) => {
            if (err) {
                console.error("Error fetching classes:", err);
                return callback(err);
            }

            // Filter out classes that the user has already taken
            const availableClasses = rows
                .map(row => row.class_name)
                .filter(class_name => !takenClasses.includes(class_name));

            console.log("Available classes for user ID", userId, ":", availableClasses);
            callback(null, availableClasses);
        });
    });
}

app.get('/dashboard', (req, res) => {
    const userId = req.query.user_id;

    db.get("SELECT * FROM users WHERE id = ?", [userId], (err, user) => {
        if (err || !user) {
            console.error("Error fetching user or user not found:", err);
            return res.status(500).send('User not found');
        }

        const courses_taken = user.classes_taken ? user.classes_taken.split(',') : [];

        getAvailableClasses(userId, (err, availableClasses) => {
            if (err) {
                console.error("Error loading available classes:", err);
                return res.status(500).send('Error loading available classes');
            }
            console.log("Rendering dashboard for user ID", userId);
            res.render('dashboard.ejs', {
                user_id: user.id,
                first_name: user.first_name,
                last_name: user.last_name,
                email: user.email,
                courses_taken,
                availableClasses,
                path: [], 
                targetClass: null, 
            });
        });
    });
});

// Adjust the route to add a class with validation
app.post('/add-class', (req, res) => {
    const { user_id, class_name } = req.body;

    db.get("SELECT * FROM users WHERE id = ?", [user_id], (err, user) => {
        if (err || !user) {
            console.error("Error fetching user or user not found:", err);
            return res.status(500).send('User not found');
        }

        const currentClassesTaken = user.classes_taken ? user.classes_taken.split(',') : [];

        // Check if the class is already taken
        if (currentClassesTaken.includes(class_name)) {
            console.log("User has already taken", class_name);
            return getAvailableClasses(user_id, (err, availableClasses) => {
                if (err) {
                    console.error("Error loading available classes:", err);
                    return res.status(500).send('Error loading available classes');
                }
                res.render('dashboard.ejs', {
                    user_id: user.id,
                    first_name: user.first_name,
                    last_name: user.last_name,
                    email: user.email,
                    courses_taken: currentClassesTaken,
                    availableClasses,
                    path: [], 
                    targetClass: null, 
                    error_message: `You have already taken ${class_name}.`
                });
            });
        }

        // Allow 100-level classes without checking prerequisites
        if (/101/.test(class_name)) {
            const updatedClassesTaken = [...new Set([...currentClassesTaken, class_name])].join(',');

            db.run(`UPDATE users SET classes_taken = ? WHERE id = ?`,
                [updatedClassesTaken, user_id], (err) => {
                    if (err) {
                        console.error("Error updating classes taken:", err);
                        return res.status(500).send('Error updating classes taken');
                    }
                    console.log("Added 100-level class:", class_name);
                    res.redirect(`/dashboard?user_id=${user_id}`);
                });
            return;
        }

        // Check prerequisites for other classes
        db.all(`
            SELECT DISTINCT c2.class_name AS prerequisite_name
            FROM classes c1
            JOIN prerequisites p ON c1.id = p.class_id
            JOIN classes c2 ON p.prerequisite_id = c2.id
            WHERE c1.class_name = ?
        `, [class_name], (err, rows) => {
            if (err) {
                console.error("Error checking prerequisites:", err);
                return res.status(500).send('Error checking prerequisites.');
            }

            console.log("Prerequisite rows for", class_name, ":", rows);

            // Filter out prerequisites that haven't been met
            const unmetPrerequisites = rows.filter(row => row.prerequisite_name && !currentClassesTaken.includes(row.prerequisite_name));

            console.log("Unmet Prerequisites for", class_name, ":", unmetPrerequisites);

            // Block class addition if prerequisites are not met
            if (unmetPrerequisites.length > 0) {
                console.log(`User is trying to add ${class_name} without meeting prerequisites.`);
                return getAvailableClasses(user_id, (err, availableClasses) => {
                    if (err) {
                        console.error("Error loading available classes:", err);
                        return res.status(500).send('Error loading available classes');
                    }
                    res.render('dashboard.ejs', {
                        user_id: user.id,
                        first_name: user.first_name,
                        last_name: user.last_name,
                        email: user.email,
                        courses_taken: currentClassesTaken,
                        availableClasses,
                        path: [], 
                        targetClass: null, 
                        error_message: `You cannot take ${class_name} because you have not completed the following prerequisites: ${[...new Set(unmetPrerequisites.map(prereq => prereq.prerequisite_name))].join(', ')}.`
                    });
                });
            }

            // If all checks pass, add the class to the user's taken classes
            const updatedClassesTaken = [...new Set([...currentClassesTaken, class_name])].join(',');

            db.run(`UPDATE users SET classes_taken = ? WHERE id = ?`,
                [updatedClassesTaken, user_id], (err) => {
                    if (err) {
                        console.error("Error updating classes taken:", err);
                        return res.status(500).send('Error updating classes taken');
                    }
                    console.log("Successfully added class:", class_name);
                    res.redirect(`/dashboard?user_id=${user_id}`);
                });
        });
    });
});

// Remove class logic
app.post('/remove-class', (req, res) => {
    const { user_id, class_name } = req.body;

    db.get("SELECT classes_taken FROM users WHERE id = ?", [user_id], (err, user) => {
        if (err || !user) {
            console.error("Error fetching user or user not found:", err);
            return res.status(500).send('User not found');
        }

        const currentClassesTaken = user.classes_taken ? user.classes_taken.split(',') : [];
        const updatedClassesTaken = currentClassesTaken.filter(c => c !== class_name).join(',');

        db.run(`UPDATE users SET classes_taken = ? WHERE id = ?`,
            [updatedClassesTaken, user_id], (err) => {
                if (err) {
                    console.error("Error updating classes taken:", err);
                    return res.status(500).send('Error updating classes taken');
                }
                console.log("Successfully removed class:", class_name);
                res.redirect(`/dashboard?user_id=${user_id}`);
            });
    });
});

// Route to export user's classes to a CSV file
app.get('/export', (req, res) => {
    const userId = req.query.user_id;

    db.get("SELECT * FROM users WHERE id = ?", [userId], (err, user) => {
        if (err || !user) {
            console.error("Error fetching user or user not found:", err);
            return res.status(500).send('User not found');
        }

        const classesTaken = user.classes_taken ? user.classes_taken.split(',') : [];
        const filePath = path.join(__dirname, `user_${userId}_classes.csv`);

        const ws = fs.createWriteStream(filePath);
        fastCsv
            .write([['Classes Taken'], ...classesTaken.map(cls => [cls])], { headers: true })
            .pipe(ws)
            .on('finish', () => {
                res.download(filePath, err => {
                    if (err) {
                        console.error('Error downloading the file:', err);
                    }
                    fs.unlinkSync(filePath); // Remove the file after download
                });
            });
    });
});

// Route to import classes from a CSV file
app.post('/import', upload.single('csv_file'), (req, res) => {
    const userId = req.body.user_id;
    const csvFile = req.file.path;

    const classesTaken = [];

    fs.createReadStream(csvFile)
        .pipe(csvParser())
        .on('data', (row) => {
            classesTaken.push(row['Classes Taken']);
        })
        .on('end', () => {
            db.get("SELECT classes_taken FROM users WHERE id = ?", [userId], (err, user) => {
                if (err || !user) {
                    console.error("Error fetching user or user not found:", err);
                    return res.status(500).send('User not found');
                }

                const currentClassesTaken = user.classes_taken ? user.classes_taken.split(',') : [];
                const updatedClassesTaken = [...new Set([...currentClassesTaken, ...classesTaken])].join(',');

                db.run(`UPDATE users SET classes_taken = ? WHERE id = ?`,
                    [updatedClassesTaken, userId], (err) => {
                        if (err) {
                            console.error("Error updating classes taken:", err);
                            return res.status(500).send('Error updating classes taken');
                        }
                        fs.unlinkSync(csvFile); // Remove the uploaded file after processing
                        res.redirect(`/dashboard?user_id=${userId}`);
                    });
            });
        });
});

// Pathfinding POST route using key-value pair-based BFS
app.post('/find-path', async (req, res) => {
    const { user_id, target_class } = req.body;

    try {
        const user = await getAsync("SELECT * FROM users WHERE id = ?", [user_id]);

        if (!user) {
            return res.status(500).send('User not found');
        }

        // Define key-value pairs representing the prerequisites
        const prerequisites = {
            'CS 201 - Data Structures': 'CS 101 - Introduction to Programming',
            'CS 301 - Algorithms': 'CS 201 - Data Structures',
            'CS 401 - Operating Systems': 'CS 301 - Algorithms',
            'CS 501 - Machine Learning': 'CS 401 - Operating Systems',
            'MATH 201 - Calculus II': 'MATH 101 - Calculus I',
            'MATH 301 - Linear Algebra': 'MATH 201 - Calculus II',
            'MATH 401 - Differential Equations': 'MATH 301 - Linear Algebra',
            'MATH 501 - Real Analysis': 'MATH 401 - Differential Equations',
            'PHYS 201 - General Physics II': 'PHYS 101 - General Physics I',
            'PHYS 301 - Modern Physics': 'PHYS 201 - General Physics II',
            'PHYS 401 - Quantum Mechanics': 'PHYS 301 - Modern Physics',
            'PHYS 501 - Statistical Mechanics': 'PHYS 401 - Quantum Mechanics',
            'CHEM 201 - Organic Chemistry I': 'CHEM 101 - General Chemistry I',
            'CHEM 301 - Organic Chemistry II': 'CHEM 201 - Organic Chemistry I',
            'CHEM 401 - Physical Chemistry': 'CHEM 301 - Organic Chemistry II',
            'CHEM 501 - Inorganic Chemistry': 'CHEM 401 - Physical Chemistry',
            'BIO 201 - Genetics': 'BIO 101 - General Biology I',
            'BIO 301 - Microbiology': 'BIO 201 - Genetics',
            'BIO 401 - Molecular Biology': 'BIO 301 - Microbiology',
            'BIO 501 - Evolutionary Biology': 'BIO 401 - Molecular Biology'
        };

        // Find the path using BFS
        const path = bfs(prerequisites, null, target_class);

        if (path.length === 0) {
            return getAvailableClasses(user_id, (err, availableClasses) => {
                if (err) {
                    console.error("Error loading available classes:", err);
                    return res.status(500).send('Error loading available classes');
                }
                res.render('dashboard.ejs', {
                    user_id,
                    first_name: user.first_name,
                    last_name: user.last_name,
                    email: user.email,
                    courses_taken: user.classes_taken ? user.classes_taken.split(',') : [],
                    availableClasses,
                    path: [], // No path found
                    targetClass: target_class,
                    error_message: 'No valid path found. Please select a different class.'
                });
            });
        }

        res.render('dashboard.ejs', {
            user_id,
            first_name: user.first_name,
            last_name: user.last_name,
            email: user.email,
            courses_taken: user.classes_taken ? user.classes_taken.split(',') : [],
            availableClasses: [],
            path,
            targetClass: target_class,
            error_message: null
        });

    } catch (err) {
        console.error('Error during pathfinding:', err);
        res.status(500).send('An error occurred while finding the path.');
    }
});

// Simple BFS function using key-value pairs
function bfs(prerequisites, startClass, targetClass) {
    const queue = [[targetClass]];
    const visited = new Set();

    while (queue.length > 0) {
        const path = queue.shift();
        const lastClass = path[path.length - 1];

        if (prerequisites[lastClass]) {
            const newPath = [...path, prerequisites[lastClass]];
            if (prerequisites[lastClass] === startClass) {
                return newPath.reverse();
            }
            queue.push(newPath);
        } else {
            return path.reverse();
        }
    }

    return [];
}


// Logout route
app.get('/logout', (req, res) => {
    console.log("User logged out.");
    res.redirect('/');
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
